/*******************************************************************************
*	�� �� �� : ������
*	�� �� �� : 2009.06.10
*	��    �� : Include Header
*******************************************************************************/

#pragma once

#pragma warning(disable : 4995)

#include <iostream>
#include <Windows.h>
#include <Wininet.h>

#include <crtdbg.h>
#include <tchar.h>
#include <strsafe.h>

#include <WZResult/WZResult.h>
#include <DownloadInfo.h>
#include <IDownloaderStateEvent.h>

#pragma comment(lib, "Wininet.lib")
