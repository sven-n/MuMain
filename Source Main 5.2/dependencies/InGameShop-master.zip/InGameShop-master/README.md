# InGameShop
MuOnline InGameShop Libraries

Decompiled by @myheart

<!-- LICENSE -->
## License

Distributed under the MIT License. See `LICENSE` for more information.


<!-- CONTACT -->
## Contact

[@myheart](https://forum.ragezone.com/members/2000236254.html) - 0x4d696e68@gmail.com

Project Thread: [https://forum.ragezone.com/f508/ingameshop-source-code-1200055/](https://forum.ragezone.com/f508/ingameshop-source-code-1200055/)

[https://forum.ragezone.com/f508/development-source-mu-main-1-a-1199222](https://forum.ragezone.com/f508/development-source-mu-main-1-a-1199222)
